from app import app
from database import init_db

# On Vercel, this module is imported once per cold start (no __main__ block runs),
# so the database must be initialized here instead of relying on `if __name__ == "__main__"`.
init_db()
