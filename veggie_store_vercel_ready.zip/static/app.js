// app.js - handles quantity selection (steps of 250g), cart total, and GPay checkout

const STEP = 250;
const MIN = 250;

const cart = {}; // { vegId: grams }

function formatMoney(n) {
  return n.toFixed(2);
}

function updateCartBar() {
  let total = 0;
  let count = 0;
  document.querySelectorAll('.veg-card').forEach(card => {
    const id = card.dataset.id;
    const grams = cart[id] || 0;
    if (grams > 0) {
      const price = parseFloat(card.dataset.price);
      total += price * (grams / 1000);
      count += 1;
    }
  });
  document.getElementById('cartCount').textContent = count;
  document.getElementById('cartTotal').textContent = formatMoney(total);
  document.getElementById('checkoutBtn').disabled = count === 0;
}

function attachCardHandlers() {
  document.querySelectorAll('.veg-card').forEach(card => {
    const id = card.dataset.id;
    const price = parseFloat(card.dataset.price);
    const qtyValueEl = card.querySelector('.qty-value');
    const lineTotalEl = card.querySelector('.line-total-value');
    const minus = card.querySelector('.minus');
    const plus = card.querySelector('.plus');

    function render() {
      const grams = cart[id] || 0;
      qtyValueEl.textContent = grams;
      lineTotalEl.textContent = formatMoney(price * (grams / 1000));
      updateCartBar();
    }

    plus.addEventListener('click', () => {
      const current = cart[id] || 0;
      cart[id] = current === 0 ? MIN : current + STEP;
      render();
    });

    minus.addEventListener('click', () => {
      const current = cart[id] || 0;
      if (current <= MIN) {
        cart[id] = 0;
      } else {
        cart[id] = current - STEP;
      }
      render();
    });

    render();
  });
}

function buildCartPayload() {
  return Object.entries(cart)
    .filter(([id, grams]) => grams > 0)
    .map(([id, grams]) => ({ id: parseInt(id, 10), grams }));
}

function openModal() { document.getElementById('payModal').classList.add('show'); }
function closeModal() { document.getElementById('payModal').classList.remove('show'); }

async function checkout() {
  const items = buildCartPayload();
  if (items.length === 0) return;

  const btn = document.getElementById('checkoutBtn');
  btn.disabled = true;
  btn.textContent = 'Processing...';

  try {
    const res = await fetch('/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items })
    });
    const data = await res.json();

    if (!res.ok) {
      alert(data.error || 'Something went wrong.');
      return;
    }

    const detailsEl = document.getElementById('payDetails');
    detailsEl.innerHTML = data.items.map(i => `
      <div class="row"><span>${i.name} (${i.grams}g)</span><span>₹${formatMoney(i.line_total)}</span></div>
    `).join('') + `<div class="row total-row"><span>Total</span><span>₹${formatMoney(data.total)}</span></div>`;

    document.getElementById('gpayLink').href = data.upi_link;
    openModal();
  } catch (err) {
    alert('Could not reach the server. Please try again.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Pay with GPay';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  attachCardHandlers();
  updateCartBar();
  document.getElementById('checkoutBtn').addEventListener('click', checkout);
  document.getElementById('closeModal').addEventListener('click', closeModal);
});
