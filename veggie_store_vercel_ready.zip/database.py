"""
Database layer for Fresh Greens.

- Local development: SQLite (store.db)
- Vercel/production: PostgreSQL when DATABASE_URL is set
"""

import os
import sqlite3
from datetime import date

DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
DB_PATH = os.path.join(os.path.dirname(__file__), "store.db")


class DBConnection:
    """Small compatibility wrapper so app.py can use conn.execute() for both DBs."""

    def __init__(self, raw, postgres=False):
        self.raw = raw
        self.postgres = postgres

    def execute(self, sql, params=()):
        if self.postgres:
            sql = sql.replace("?", "%s")
            return self.raw.execute(sql, params)
        return self.raw.execute(sql, params)

    def commit(self):
        self.raw.commit()

    def close(self):
        self.raw.close()


def get_connection():
    if DATABASE_URL:
        import psycopg
        from psycopg.rows import dict_row
        raw = psycopg.connect(DATABASE_URL, row_factory=dict_row)
        return DBConnection(raw, postgres=True)

    raw = sqlite3.connect(DB_PATH)
    raw.row_factory = sqlite3.Row
    raw.execute("PRAGMA foreign_keys = ON")
    return DBConnection(raw, postgres=False)


def init_db(reset=False):
    conn = get_connection()

    if reset:
        conn.execute("DROP TABLE IF EXISTS vegetables")
        conn.execute("DROP TABLE IF EXISTS shop")
        conn.execute("DROP TABLE IF EXISTS orders")

    if DATABASE_URL:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS shop (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                name TEXT NOT NULL,
                address TEXT NOT NULL,
                upi_id TEXT NOT NULL DEFAULT ''
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS vegetables (
                id SERIAL PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                price_per_kg DOUBLE PRECISION NOT NULL,
                image_url TEXT NOT NULL DEFAULT '',
                stock_grams INTEGER NOT NULL DEFAULT 0,
                available INTEGER NOT NULL DEFAULT 1,
                last_updated TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id SERIAL PRIMARY KEY,
                items_json TEXT NOT NULL,
                total_amount DOUBLE PRECISION NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
    else:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS shop (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                name TEXT NOT NULL,
                address TEXT NOT NULL,
                upi_id TEXT NOT NULL DEFAULT ''
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS vegetables (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                price_per_kg REAL NOT NULL,
                image_url TEXT NOT NULL DEFAULT '',
                stock_grams INTEGER NOT NULL DEFAULT 0,
                available INTEGER NOT NULL DEFAULT 1,
                last_updated TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                items_json TEXT NOT NULL,
                total_amount REAL NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

    row = conn.execute("SELECT COUNT(*) AS c FROM shop").fetchone()
    if row["c"] == 0:
        conn.execute(
            "INSERT INTO shop (id, name, address, upi_id) VALUES (1, ?, ?, ?)",
            (
                "Fresh Greens Vegetable Store",
                "12, Market Street, Tiruvottiyur, Chennai, Tamil Nadu",
                "yourshop@upi",
            ),
        )

    row = conn.execute("SELECT COUNT(*) AS c FROM vegetables").fetchone()
    if row["c"] == 0:
        today = date.today().isoformat()
        sample = [
            ("Tomato", 30.0, "https://images.unsplash.com/photo-1546094096-0df4bcaaa337?w=400", 5000, today),
            ("Onion", 40.0, "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?w=400", 8000, today),
            ("Potato", 25.0, "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400", 10000, today),
            ("Carrot", 50.0, "https://images.unsplash.com/photo-1447175008436-054170c2e979?w=400", 4000, today),
            ("Cabbage", 20.0, "https://images.unsplash.com/photo-1594282486552-05b4d80fbb9f?w=400", 3000, today),
            ("Cauliflower", 35.0, "https://images.unsplash.com/photo-1568584711271-6c929fb49b60?w=400", 3500, today),
            ("Brinjal", 45.0, "https://images.unsplash.com/photo-1613836260375-c50d4c8c3b1f?w=400", 2500, today),
            ("Ladies Finger", 55.0, "https://images.unsplash.com/photo-1656583553359-c93bf2b8ec3d?w=400", 2000, today),
        ]
        conn.execute(
            """INSERT INTO vegetables
               (name, price_per_kg, image_url, stock_grams, available, last_updated)
               VALUES (?, ?, ?, ?, 1, ?)""",
            sample[0],
        )
        # Use executemany on the underlying cursor/connection for portability.
        for item in sample[1:]:
            conn.execute(
                """INSERT INTO vegetables
                   (name, price_per_kg, image_url, stock_grams, available, last_updated)
                   VALUES (?, ?, ?, ?, 1, ?)""",
                item,
            )

    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db(reset=True)
    print("Database initialized.")
