"""
app.py
Flask backend for the Grocery (Vegetable) Store application.

Customer side:
  - View shop name & address
  - Browse vegetables with photo + price per kg (updated daily by owner)
  - Select quantity in steps of 250g (minimum 250g)
  - See live total for the cart
  - Checkout -> generates a GPay/UPI payment link with the exact amount

Owner/Admin side:
  - Login with a simple password
  - Add new vegetable (name, price/kg, photo URL, stock)
  - Update price / stock / photo of existing vegetable
  - Remove a vegetable
  - Update shop name/address/UPI id
"""

import json
import urllib.parse
from datetime import date, datetime

from flask import Flask, render_template, request, redirect, url_for, jsonify, session, flash

from database import get_connection, init_db, DB_PATH
import os

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me")

# Simple hardcoded admin credentials (replace with a real auth system for production use)
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "owner")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "owner123")

MIN_GRAMS = 250       # minimum purchasable quantity
STEP_GRAMS = 250       # increment step


def admin_required(func):
    from functools import wraps

    @wraps(func)
    def wrapper(*args, **kwargs):
        if not session.get("is_admin"):
            return redirect(url_for("admin_login"))
        return func(*args, **kwargs)
    return wrapper


# ---------------------------------------------------------------------------
# Customer-facing routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    conn = get_connection()
    shop = conn.execute("SELECT * FROM shop WHERE id = 1").fetchone()
    vegetables = conn.execute(
        "SELECT * FROM vegetables WHERE available = 1 ORDER BY name"
    ).fetchall()
    conn.close()
    return render_template(
        "index.html",
        shop=shop,
        vegetables=vegetables,
        min_grams=MIN_GRAMS,
        step_grams=STEP_GRAMS,
    )


@app.route("/api/checkout", methods=["POST"])
def checkout():
    """
    Expects JSON: { "items": [ {"id": 1, "grams": 500}, ... ] }
    Validates quantities, computes total from DB prices (never trust client price),
    stores the order, and returns a UPI/GPay deep link.
    """
    data = request.get_json(force=True)
    items = data.get("items", [])
    if not items:
        return jsonify({"error": "Cart is empty."}), 400

    conn = get_connection()
    shop = conn.execute("SELECT * FROM shop WHERE id = 1").fetchone()

    total = 0.0
    order_lines = []
    for item in items:
        veg_id = item.get("id")
        grams = int(item.get("grams", 0))

        if grams < MIN_GRAMS or grams % STEP_GRAMS != 0:
            conn.close()
            return jsonify({
                "error": f"Quantity must be at least {MIN_GRAMS}g and in steps of {STEP_GRAMS}g."
            }), 400

        veg = conn.execute("SELECT * FROM vegetables WHERE id = ?", (veg_id,)).fetchone()
        if not veg or not veg["available"]:
            conn.close()
            return jsonify({"error": "One of the items is no longer available."}), 400

        line_total = round(veg["price_per_kg"] * (grams / 1000.0), 2)
        total += line_total
        order_lines.append({
            "name": veg["name"],
            "grams": grams,
            "price_per_kg": veg["price_per_kg"],
            "line_total": line_total
        })

    total = round(total, 2)

    conn.execute(
        "INSERT INTO orders (items_json, total_amount, created_at) VALUES (?, ?, ?)",
        (json.dumps(order_lines), total, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()

    # Build a standard UPI deep link (opens Google Pay / any UPI app on mobile)
    note = f"Order at {shop['name']}"
    params = {
        "pa": shop["upi_id"],       # payee UPI address
        "pn": shop["name"],         # payee name
        "am": f"{total:.2f}",       # amount
        "cu": "INR",
        "tn": note,
    }
    upi_link = "upi://pay?" + urllib.parse.urlencode(params)

    return jsonify({
        "total": total,
        "items": order_lines,
        "upi_link": upi_link
    })


# ---------------------------------------------------------------------------
# Admin (owner) routes
# ---------------------------------------------------------------------------

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session["is_admin"] = True
            return redirect(url_for("admin_dashboard"))
        flash("Invalid username or password.")
    return render_template("admin_login.html")


@app.route("/admin/logout")
def admin_logout():
    session.pop("is_admin", None)
    return redirect(url_for("index"))


@app.route("/admin")
@admin_required
def admin_dashboard():
    conn = get_connection()
    shop = conn.execute("SELECT * FROM shop WHERE id = 1").fetchone()
    vegetables = conn.execute("SELECT * FROM vegetables ORDER BY name").fetchall()
    conn.close()
    return render_template("admin.html", shop=shop, vegetables=vegetables)


@app.route("/admin/shop", methods=["POST"])
@admin_required
def admin_update_shop():
    name = request.form.get("name", "").strip()
    address = request.form.get("address", "").strip()
    upi_id = request.form.get("upi_id", "").strip()
    conn = get_connection()
    conn.execute(
        "UPDATE shop SET name = ?, address = ?, upi_id = ? WHERE id = 1",
        (name, address, upi_id)
    )
    conn.commit()
    conn.close()
    flash("Shop details updated.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/vegetable/add", methods=["POST"])
@admin_required
def admin_add_vegetable():
    name = request.form.get("name", "").strip()
    price = request.form.get("price_per_kg", "0").strip()
    image_url = request.form.get("image_url", "").strip()
    stock = request.form.get("stock_grams", "0").strip()

    try:
        price = float(price)
        stock = int(stock)
    except ValueError:
        flash("Price and stock must be numbers.")
        return redirect(url_for("admin_dashboard"))

    conn = get_connection()
    try:
        conn.execute(
            """INSERT INTO vegetables (name, price_per_kg, image_url, stock_grams, available, last_updated)
               VALUES (?, ?, ?, ?, 1, ?)""",
            (name, price, image_url, stock, date.today().isoformat())
        )
        conn.commit()
        flash(f"Added '{name}'.")
    except Exception as e:
        flash(f"Could not add vegetable: {e}")
    conn.close()
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/vegetable/<int:veg_id>/update", methods=["POST"])
@admin_required
def admin_update_vegetable(veg_id):
    price = request.form.get("price_per_kg")
    image_url = request.form.get("image_url")
    stock = request.form.get("stock_grams")
    available = 1 if request.form.get("available") == "on" else 0

    conn = get_connection()
    conn.execute(
        """UPDATE vegetables
           SET price_per_kg = ?, image_url = ?, stock_grams = ?, available = ?, last_updated = ?
           WHERE id = ?""",
        (float(price), image_url, int(stock), available, date.today().isoformat(), veg_id)
    )
    conn.commit()
    conn.close()
    flash("Vegetable updated.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/vegetable/<int:veg_id>/delete", methods=["POST"])
@admin_required
def admin_delete_vegetable(veg_id):
    conn = get_connection()
    conn.execute("DELETE FROM vegetables WHERE id = ?", (veg_id,))
    conn.commit()
    conn.close()
    flash("Vegetable removed.")
    return redirect(url_for("admin_dashboard"))


if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
