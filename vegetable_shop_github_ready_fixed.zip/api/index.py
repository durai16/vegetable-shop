from app import app

# Vercel entrypoint for the Flask application.
