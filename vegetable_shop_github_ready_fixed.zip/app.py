"""
Fresh Greens Vegetable Store - Flask application.

Customer:
- Register with name, address, and phone or email.
- Create a 6-digit numeric password.
- Login using phone OR email + password.
- Checkout is available only to logged-in customers.
- Customer details are stored with the order and sent to the shop by email/SMS.

Owner:
- Owner login via environment variables.
- Manage shop contact information and vegetables.
"""

import base64
import json
import os
import urllib.parse
import urllib.request
from datetime import date, datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, jsonify, session, flash
from werkzeug.security import generate_password_hash, check_password_hash

from database import get_connection, init_db, DB_PATH

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me")

ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "owner")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "owner123")

MIN_GRAMS = 250
STEP_GRAMS = 250


def admin_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not session.get("is_admin"):
            return redirect(url_for("admin_login"))
        return func(*args, **kwargs)
    return wrapper


def customer_required_api():
    customer_id = session.get("customer_id")
    if not customer_id:
        return None, jsonify({"error": "Please login before placing an order.", "login_required": True}), 401
    conn = get_connection()
    customer = conn.execute("SELECT * FROM customers WHERE id = ?", (customer_id,)).fetchone()
    if not customer:
        conn.close()
        session.pop("customer_id", None)
        return None, jsonify({"error": "Your session has expired. Please login again.", "login_required": True}), 401
    return customer, None, None


# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------

def send_order_email(order_id, shop, customer, order_lines, total):
    api_key = os.environ.get("RESEND_API_KEY", "").strip()
    email_from = os.environ.get("EMAIL_FROM", "").strip()
    recipient = (shop["email"] or "").strip()

    if not api_key or not email_from or not recipient:
        return False, "Email notification is not configured."

    lines = "\n".join(
        f"- {x['name']}: {x['grams']}g = ₹{x['line_total']:.2f}"
        for x in order_lines
    )
    payload = {
        "from": email_from,
        "to": [recipient],
        "subject": f"New Vegetable Order #{order_id} - ₹{total:.2f}",
        "text": (
            f"NEW ORDER #{order_id}\n\n"
            f"Customer name: {customer['name']}\n"
            f"Customer phone: {customer['phone'] or 'Not provided'}\n"
            f"Customer email: {customer['email'] or 'Not provided'}\n"
            f"Delivery address: {customer['address']}\n\n"
            f"Items:\n{lines}\n\n"
            f"Total: ₹{total:.2f}\n"
            f"Shop: {shop['name']}\n"
        ),
    }

    req = urllib.request.Request(
        "https://api.resend.com/emails",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            return 200 <= response.status < 300, "Email sent."
    except Exception as exc:
        print(f"Email notification failed: {exc}")
        return False, "Email notification failed."


def send_order_sms(order_id, shop, customer, order_lines, total):
    sid = os.environ.get("TWILIO_ACCOUNT_SID", "").strip()
    token = os.environ.get("TWILIO_AUTH_TOKEN", "").strip()
    from_number = os.environ.get("TWILIO_FROM_NUMBER", "").strip()
    to_number = (shop["phone"] or "").strip()

    if not sid or not token or not from_number or not to_number:
        return False, "SMS notification is not configured."

    items = ", ".join(f"{x['name']} {x['grams']}g" for x in order_lines)
    body = (
        f"NEW ORDER #{order_id} | {shop['name']}\n"
        f"Customer: {customer['name']}\n"
        f"Phone: {customer['phone'] or 'N/A'}\n"
        f"Address: {customer['address']}\n"
        f"Items: {items}\n"
        f"Total: ₹{total:.2f}"
    )

    auth = base64.b64encode(f"{sid}:{token}".encode()).decode()
    form = urllib.parse.urlencode({
        "From": from_number,
        "To": to_number,
        "Body": body[:1500],
    }).encode("utf-8")

    req = urllib.request.Request(
        f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json",
        data=form,
        headers={
            "Authorization": f"Basic {auth}",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            return 200 <= response.status < 300, "SMS sent."
    except Exception as exc:
        print(f"SMS notification failed: {exc}")
        return False, "SMS notification failed."


def notify_order(order_id, shop, customer, order_lines, total):
    send_order_email(order_id, shop, customer, order_lines, total)
    send_order_sms(order_id, shop, customer, order_lines, total)


# ---------------------------------------------------------------------------
# Customer routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    conn = get_connection()
    shop = conn.execute("SELECT * FROM shop WHERE id = 1").fetchone()
    vegetables = conn.execute(
        "SELECT * FROM vegetables WHERE available = 1 ORDER BY name"
    ).fetchall()
    customer = None
    if session.get("customer_id"):
        customer = conn.execute(
            "SELECT id, name, address, phone, email FROM customers WHERE id = ?",
            (session["customer_id"],)
        ).fetchone()
    conn.close()

    return render_template(
        "index.html",
        shop=shop,
        vegetables=vegetables,
        min_grams=MIN_GRAMS,
        step_grams=STEP_GRAMS,
        customer=customer,
    )


@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("customer_id"):
        return redirect(url_for("index"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        address = request.form.get("address", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "").strip()
        confirm = request.form.get("confirm_password", "").strip()

        errors = []
        if len(name) < 2:
            errors.append("Enter your full name.")
        if len(address) < 5:
            errors.append("Enter your complete delivery address.")
        if not phone and not email:
            errors.append("Enter at least a phone number or email address.")
        if phone and not re_phone(phone):
            errors.append("Enter a valid phone number.")
        if email and not re_email(email):
            errors.append("Enter a valid email address.")
        if not (password.isdigit() and len(password) == 6):
            errors.append("Password must contain exactly 6 digits.")
        if password != confirm:
            errors.append("Passwords do not match.")

        if errors:
            for e in errors:
                flash(e)
            return render_template("register.html")

        conn = get_connection()
        duplicate = None
        if phone:
            duplicate = conn.execute(
                "SELECT id FROM customers WHERE phone = ?", (phone,)
            ).fetchone()
        if not duplicate and email:
            duplicate = conn.execute(
                "SELECT id FROM customers WHERE LOWER(email) = ?", (email,)
            ).fetchone()

        if duplicate:
            conn.close()
            flash("A customer account already exists with this phone number or email.")
            return render_template("register.html")

        conn.execute(
            """INSERT INTO customers
               (name, address, phone, email, password_hash, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                name,
                address,
                phone or None,
                email or None,
                generate_password_hash(password),
                datetime.now().isoformat(),
            ),
        )
        customer = conn.execute(
            "SELECT id FROM customers ORDER BY id DESC LIMIT 1"
        ).fetchone()
        conn.commit()
        conn.close()

        session["customer_id"] = customer["id"]
        flash("Registration successful. You are now logged in.")
        return redirect(url_for("index"))

    return render_template("register.html")


def re_email(value):
    import re
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value))


def re_phone(value):
    import re
    digits = re.sub(r"\D", "", value)
    return 10 <= len(digits) <= 15


@app.route("/login", methods=["GET", "POST"])
def customer_login():
    if session.get("customer_id"):
        return redirect(url_for("index"))

    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip()
        password = request.form.get("password", "").strip()

        conn = get_connection()
        customer = conn.execute(
            """SELECT * FROM customers
               WHERE phone = ? OR LOWER(email) = ?
               LIMIT 1""",
            (identifier, identifier.lower())
        ).fetchone()
        conn.close()

        if customer and check_password_hash(customer["password_hash"], password):
            session["customer_id"] = customer["id"]
            return redirect(url_for("index"))

        flash("Invalid phone/email or password.")

    return render_template("login.html")


@app.route("/logout")
def customer_logout():
    session.pop("customer_id", None)
    return redirect(url_for("index"))


@app.route("/api/checkout", methods=["POST"])
def checkout():
    customer, error_response, error_status = customer_required_api()
    if error_response:
        return error_response, error_status

    data = request.get_json(force=True) or {}
    items = data.get("items", [])
    if not items:
        return jsonify({"error": "Cart is empty."}), 400

    conn = get_connection()
    shop = conn.execute("SELECT * FROM shop WHERE id = 1").fetchone()

    total = 0.0
    order_lines = []

    try:
        for item in items:
            veg_id = item.get("id")
            grams = int(item.get("grams", 0))

            if grams < MIN_GRAMS or grams % STEP_GRAMS != 0:
                return jsonify({
                    "error": f"Quantity must be at least {MIN_GRAMS}g and in steps of {STEP_GRAMS}g."
                }), 400

            veg = conn.execute(
                "SELECT * FROM vegetables WHERE id = ?", (veg_id,)
            ).fetchone()
            if not veg or not veg["available"]:
                return jsonify({"error": "One of the items is no longer available."}), 400

            if grams > int(veg["stock_grams"]):
                return jsonify({
                    "error": f"Only {veg['stock_grams']}g of {veg['name']} is available."
                }), 400

            line_total = round(veg["price_per_kg"] * (grams / 1000.0), 2)
            total += line_total
            order_lines.append({
                "name": veg["name"],
                "grams": grams,
                "price_per_kg": veg["price_per_kg"],
                "line_total": line_total,
            })

        total = round(total, 2)

        conn.execute(
            """INSERT INTO orders
               (customer_id, items_json, total_amount, created_at)
               VALUES (?, ?, ?, ?)""",
            (
                customer["id"],
                json.dumps(order_lines),
                total,
                datetime.now().isoformat(),
            )
        )
        order_row = conn.execute(
            "SELECT * FROM orders ORDER BY id DESC LIMIT 1"
        ).fetchone()
        order_id = order_row["id"]

        # Reduce stock after order is recorded.
        for item in items:
            conn.execute(
                """UPDATE vegetables
                   SET stock_grams = stock_grams - ?
                   WHERE id = ?""",
                (int(item["grams"]), int(item["id"]))
            )

        conn.commit()
    finally:
        conn.close()

    notify_order(order_id, shop, customer, order_lines, total)

    note = f"Order #{order_id} at {shop['name']}"
    params = {
        "pa": shop["upi_id"],
        "pn": shop["name"],
        "am": f"{total:.2f}",
        "cu": "INR",
        "tn": note,
    }
    upi_link = "upi://pay?" + urllib.parse.urlencode(params)

    return jsonify({
        "order_id": order_id,
        "total": total,
        "items": order_lines,
        "upi_link": upi_link,
    })


# ---------------------------------------------------------------------------
# Admin routes
# ---------------------------------------------------------------------------

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session["is_admin"] = True
            return redirect(url_for("admin_dashboard"))
        flash("Invalid username or password.")
    return render_template("admin_login.html")


@app.route("/admin/logout")
def admin_logout():
    session.pop("is_admin", None)
    return redirect(url_for("index"))


@app.route("/admin")
@admin_required
def admin_dashboard():
    conn = get_connection()
    shop = conn.execute("SELECT * FROM shop WHERE id = 1").fetchone()
    vegetables = conn.execute("SELECT * FROM vegetables ORDER BY name").fetchall()
    conn.close()
    return render_template("admin.html", shop=shop, vegetables=vegetables)


@app.route("/admin/shop", methods=["POST"])
@admin_required
def admin_update_shop():
    name = request.form.get("name", "").strip()
    address = request.form.get("address", "").strip()
    upi_id = request.form.get("upi_id", "").strip()
    email = request.form.get("email", "").strip()
    phone = request.form.get("phone", "").strip()

    conn = get_connection()
    conn.execute(
        """UPDATE shop SET name = ?, address = ?, upi_id = ?, email = ?, phone = ?
           WHERE id = 1""",
        (name, address, upi_id, email, phone)
    )
    conn.commit()
    conn.close()
    flash("Shop details updated.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/vegetable/add", methods=["POST"])
@admin_required
def admin_add_vegetable():
    name = request.form.get("name", "").strip()
    price = request.form.get("price_per_kg", "0").strip()
    image_url = request.form.get("image_url", "").strip()
    stock = request.form.get("stock_grams", "0").strip()

    try:
        price = float(price)
        stock = int(stock)
    except ValueError:
        flash("Price and stock must be numbers.")
        return redirect(url_for("admin_dashboard"))

    conn = get_connection()
    try:
        conn.execute(
            """INSERT INTO vegetables
               (name, price_per_kg, image_url, stock_grams, available, last_updated)
               VALUES (?, ?, ?, ?, 1, ?)""",
            (name, price, image_url, stock, date.today().isoformat())
        )
        conn.commit()
        flash(f"Added '{name}'.")
    except Exception as e:
        flash(f"Could not add vegetable: {e}")
    conn.close()
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/vegetable/<int:veg_id>/update", methods=["POST"])
@admin_required
def admin_update_vegetable(veg_id):
    price = request.form.get("price_per_kg")
    image_url = request.form.get("image_url")
    stock = request.form.get("stock_grams")
    available = 1 if request.form.get("available") == "on" else 0

    conn = get_connection()
    conn.execute(
        """UPDATE vegetables
           SET price_per_kg = ?, image_url = ?, stock_grams = ?, available = ?, last_updated = ?
           WHERE id = ?""",
        (float(price), image_url, int(stock), available, date.today().isoformat(), veg_id)
    )
    conn.commit()
    conn.close()
    flash("Vegetable updated.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/vegetable/<int:veg_id>/delete", methods=["POST"])
@admin_required
def admin_delete_vegetable(veg_id):
    conn = get_connection()
    conn.execute("DELETE FROM vegetables WHERE id = ?", (veg_id,))
    conn.commit()
    conn.close()
    flash("Vegetable removed.")
    return redirect(url_for("admin_dashboard"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
