# Fresh Greens — Vegetable Store Web App

A simple, user-friendly grocery/vegetable store web application.

**Tech stack:** Python (Flask) + SQL (SQLite) + HTML/CSS/JavaScript frontend.

## Features

**Customer side**
- Shows shop name and address at the top.
- Displays all available vegetables with photo and price per kg (updated daily by the owner).
- Quantity selector works in steps of 250g, with a minimum order of 250g per item.
- Running total updates live as you add items.
- "Pay with GPay" button calculates the total and opens a UPI payment link
  (`upi://pay?...`) pre-filled with the shop's UPI ID and the exact amount —
  this opens Google Pay (or any UPI app) directly on a phone.

**Owner/Admin side** (`/admin/login`)
- Default login: username `owner`, password `owner123` — **change these before going live.**
- Add a new vegetable (name, price/kg, photo URL, starting stock).
- Update price, stock, photo, or availability of any vegetable at any time (e.g. daily).
- Remove a vegetable from the store.
- Edit the shop name, address, and UPI ID used for GPay payments.

## Project structure

```
veggie_store/
├── app.py              # Flask app: routes + API
├── database.py         # SQLite schema + seed data
├── requirements.txt
├── templates/
│   ├── index.html       # customer storefront
│   ├── admin.html        # owner dashboard
│   └── admin_login.html
└── static/
    ├── style.css
    └── app.js            # cart logic + GPay checkout
```

## Setup

1. Install Python 3.9+ and pip.
2. From inside the `veggie_store` folder:

   ```bash
   pip install -r requirements.txt
   python database.py       # creates store.db with sample vegetables
   python app.py
   ```
3. Open **http://localhost:5000** in your browser for the customer view.
4. Open **http://localhost:5000/admin/login** for the owner dashboard.

## Important: set your real UPI ID

In the admin dashboard, under **Shop Details**, replace the placeholder
UPI ID (`yourshop@upi`) with your real UPI ID (e.g. `9876543210@okaxis` or
your bank's UPI handle) so the "Pay with GPay" button sends money to your
actual account. The link format is the standard UPI deep-link scheme,
which Google Pay, PhonePe, Paytm, and other UPI apps all understand.

## Notes / things to harden before real deployment

- Replace the hardcoded admin username/password with a proper user table
  and hashed passwords.
- Serve over HTTPS and set a strong, random `app.secret_key`.
- Vegetable photos are currently entered as image URLs; you could extend
  `admin_add_vegetable` to accept file uploads if you want photos hosted
  locally.
- Swap SQLite for PostgreSQL/MySQL if you expect heavy concurrent traffic.
- The UPI link opens the user's payment app to *request* payment — it does
  not automatically confirm payment back to your server. For automatic
  payment confirmation you'd need a payment gateway with webhook support
  (e.g. Razorpay, Cashfree) instead of a raw UPI link.


## Vercel deployment

This version supports:
- SQLite for local development.
- PostgreSQL for Vercel/production.
- Flask through `api/index.py`.
- Vercel routing through `vercel.json`.

### Local test

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python database.py
python app.py
```

Open `http://localhost:5000`.

### GitHub + Vercel

1. Create a GitHub repository.
2. Upload all files in this folder (do not upload `.env`, `store.db`, or `venv`).
3. Import the GitHub repository into Vercel.
4. Create a PostgreSQL database (Vercel Postgres or another PostgreSQL provider).
5. In Vercel Project Settings -> Environment Variables, add:
   - `DATABASE_URL`
   - `SECRET_KEY`
   - `ADMIN_USERNAME`
   - `ADMIN_PASSWORD`
6. Redeploy.
7. Open your Vercel domain.

### Important

SQLite is only for local development. On Vercel, use PostgreSQL so products, shop details and orders persist.

The UPI link opens the customer's UPI app; it does not automatically verify payment. For automatic payment confirmation, use a payment gateway with webhooks.

## Shop contact + order notifications

The public store now shows the shop email and phone number. The owner can edit both from **Owner Dashboard -> Shop Details**.

When checkout creates an order, the app can notify the shop:
- Email: Resend API
- SMS: Twilio

Add these Vercel environment variables:
- `RESEND_API_KEY`
- `EMAIL_FROM`
- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_FROM_NUMBER`

The shop's destination email and phone are stored in the `shop` table and edited from the admin dashboard.

Important: the current checkout creates the order when the customer clicks checkout and opens the UPI/GPay payment link. It does **not** verify that the payment was actually completed. For payment-confirmed notifications, integrate a payment gateway/webhook.


## Customer accounts

Customers can:
1. Register with name, delivery address, and at least a phone number or email.
2. Create a 6-digit numeric password.
3. Login using their phone number OR email plus the password.
4. Place an order only after login.
5. Their name, address, phone, email, order items, total, and timestamp are stored in PostgreSQL.
6. Shop email/SMS notifications include the customer's name, phone, email, delivery address, items, and total.

Passwords are stored as secure hashes, not as plain 6-digit text.

### Important security note

A 6-digit password is convenient but weak. For a real public store, add rate limiting and preferably use OTP/passkey or a stronger password. The current implementation follows the requested 6-digit login flow.

### Vercel routing
The project uses `api/index.py` as the Flask serverless function. The root URL is
rewritten to `/api/index`, so the storefront is available directly at `/`.
