import os
from app import app
from database import init_db

# Initialize tables on cold start. PostgreSQL is persistent; local SQLite is used only locally.
init_db()

# Vercel detects this Flask application as the Python serverless function.
